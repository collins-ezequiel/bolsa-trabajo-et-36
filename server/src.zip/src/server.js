const express = require('express');
const app = express();
require('dotenv').config();

app.use(express.json());

const authRoutes = require('./routes/auth');
const offersRoutes = require('./routes/offers');

app.use('/api/auth', authRoutes);
app.use('/api/ofertas', offersRoutes);

const PORT = process.env.PORT || 3005;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
